# EmulatorOS.github.io
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
[![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/Emulatoros/emulatoros.github.io)
[<img src="https://camo.githubusercontent.com/aaa5efab04d69a070ff9ee9f75506b38932a7300359318135f4790c31b7dace4/68747470733a2f2f7265706c2e69742f62616467652f6769746875622f756e6b6e6f776e626c7565677579362f4d696e6553776565706572" alt="Deploy instance on Replit" height="33px">](https://replit.com/github/Emulatoros/emulatoros.github.io)

Or you can fork this repository and host with GitHub Pages.
All the different repositories you need are: [GData](https://github.com/EmulatorOS/gdata), [GFile](https://github.com/EmulatorOS/gfile), [Img](https://github.com/EmulatorOS/img),and [Game Pages](https://github.com/EmulatorOS/games)
